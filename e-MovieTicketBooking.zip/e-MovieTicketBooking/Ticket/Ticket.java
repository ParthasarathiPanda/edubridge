package Ticket;

public class Ticket {

	public Ticket() {
		// TODO Auto-generated constructor stub
	}

}
