package Cancel;

public class Cancel {

	public Cancel() {
		System.out.println("Cancelled !");
	}

}
