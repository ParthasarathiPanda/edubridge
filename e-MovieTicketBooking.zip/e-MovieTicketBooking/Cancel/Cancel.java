package Cancel;

public class Cancel {

	public Cancel() {
		String s="😞";
		System.out.println("Cancelled ! "+s);
	}

}
