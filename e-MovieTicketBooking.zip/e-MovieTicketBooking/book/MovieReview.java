package book;

import java.io.FileReader;

public class MovieReview {

	public MovieReview() {
		int ch;
		System.out.println("\n\n");
		try {
			FileReader filereader= new FileReader("test.txt");
			do {
				ch=filereader.read();
				System.out.print((char)ch+"");
				}while(ch!=-1);
		}
		catch(Exception ex) {
			System.out.println("Error "+ex.getMessage());
		}
		
		System.out.println("\n\n");
	}

}
