package book;

import java.util.HashMap;
import java.util.Scanner;

public class Ticket {
	
	static int TicketNumber=100;

	public static int getTicket() {
			
			return TicketNumber;
			
		}
	
	public static void setTicket(int numbersOfTickets) {
		TicketNumber -= numbersOfTickets;
		
	}

	public static void AdminSetTkt(int numOfTkt) {
		TicketNumber += numOfTkt;
		
	}
	
	

}
