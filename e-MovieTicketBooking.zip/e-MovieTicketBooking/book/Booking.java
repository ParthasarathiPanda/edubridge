package book;

import java.util.Scanner;

import Ticket.Ticket;

public class Booking {

	public Booking() {
		Scanner scanner=new Scanner(System.in);
		String movieName;
		//Ticket ticket = new Ticket();
		System.out.println("Enter the Name of the Movie");
		movieName=scanner.next();
		System.out.println(movieName+" Booking Successfull !!!");
	}

}
