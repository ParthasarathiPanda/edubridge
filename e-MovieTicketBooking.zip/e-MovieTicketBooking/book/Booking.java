package book;

import java.io.FileReader;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


import book.Ticket;

public class Booking {
	static HashMap<Integer, String> movie = new HashMap<Integer, String>();
	

	public Booking() {
		
		movie.put(1, "ABCD");
		movie.put(2, "JOKER");
		movie.put(3, "KANTARA");
		movie.put(4, "ASUR");
		movie.put(5, "PUSHPA");
		
	}

	public static void display() {
		for(Map.Entry m : movie.entrySet()){    
		    System.out.println(m.getKey()+" "+m.getValue());    
		   }  
		
	}

	public static void SetMovie(int MovieNumber,String newMovieName) {
		movie.put(MovieNumber, newMovieName);
		
	}

	public static void ChangeMovieName(int movieNum, String movieName) {
		String returned_value = (String)movie.put(movieNum, movieName);
		
	}

	public static void RemoveMovie(int movieNumRem) {
		String returned_value = (String)movie.remove(movieNumRem);
		
	}

	public static void book(int customerChoice) {
		Scanner scanner= new Scanner(System.in);
		boolean Avilability=movie.containsKey(customerChoice);
		if(Avilability) {
			System.out.println("Number of avilable ticket is "+Ticket.getTicket());
			System.out.println("How many tickets you want to book");
			int NumbersOfTickets=scanner.nextInt();
			int AvilableTickets=Ticket.getTicket();
			
			
			if(AvilableTickets >= NumbersOfTickets) {
				String s = "😀"; 
				System.out.println(customerChoice+" Booking successfull "+ s);
				Ticket.setTicket(NumbersOfTickets);
				MovieReview mr= new MovieReview();
			}
			
		}
			
	}


}
