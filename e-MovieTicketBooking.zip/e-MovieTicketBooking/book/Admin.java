package book;

import Cancel.Cancel;
import java.util.Scanner;

public class Admin {

	public Admin() {
		Scanner scanner= new Scanner(System.in);
		String name;
		int password;
		System.out.println("Enter User Name");
		name = scanner.nextLine();
		System.out.println("Enter Password");
		password= scanner.nextInt();
		
		
		if(name.equals("partha") && password==123) {
			char option;
			do {
				System.out.println("Enter Your Choice");
				System.out.println("1: Add New Ticket \n2:Add Movie");
				int choice= scanner.nextInt();
				switch(choice) {
				case 1:
					Booking booking = new Booking();
					break;
				case 2:
					Cancel cancel= new Cancel();
					break;
				default:
					System.out.println("invalid choice");
					break;
				}
				System.out.println("Do you want to continue (y/n)");
				option=scanner.next().charAt(0);
			}while(option=='y' || option=='Y');
		}else {
			System.out.println("Invalid Username or Password");
		}
	}

}
