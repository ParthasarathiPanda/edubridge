package book;

import Cancel.Cancel;
import java.util.Scanner;

public class Admin {

	public Admin() {
		
		Scanner scanner= new Scanner(System.in);
		String name;
		int password;
		System.out.println("Enter User Name");
		name = scanner.nextLine();
		System.out.println("Enter Password");
		password= scanner.nextInt();
		
				if(name.equals("partha") && password==123) {
					char option;
					do {
						System.out.println("Enter Your Choice");
						System.out.println(" 1: Add New movie \n 2: change a movie name \n 3: Delete a Movie \n 4: add tickets");
						int choice= scanner.nextInt();
						switch(choice) {
						case 1:
							
							Booking.display();
							System.out.println("enter the movie number and name to add");
							int MovieNumber=scanner.nextInt();
							String NewMovieName=scanner.next();
							Booking.SetMovie(MovieNumber ,NewMovieName);
							Booking.display();
							break;
							
						case 2:
							
							Booking.display();
							System.out.println("enter the movie number and new name");
							int MovieNum=scanner.nextInt();
							String MovieName=scanner.next();
							Booking.ChangeMovieName(MovieNum ,MovieName);
							Booking.display();
							break;
							
							case 3:
							Booking.display();
							System.out.println("enter the movie number to remove");
							int MovieNumRem=scanner.nextInt();
							Booking.RemoveMovie(MovieNumRem);
							Booking.display();
							break;
							
						case 4:
							System.out.println("Avilable tickts "+ Ticket.getTicket());
							System.out.println("how many tickets you want to add");
							int NumOfTkt=scanner.nextInt();
							Ticket.AdminSetTkt(NumOfTkt);
							System.out.println("Avilable tickts "+ Ticket.getTicket());
							break;
						default:
							System.out.println("invalid choice");
							break;
						}
						System.out.println("Do you want to continue (y/n)");
						option=scanner.next().charAt(0);
					}while(option=='y' || option=='Y');
				}else {
					System.out.println("Invalid Username or Password");
				}
		
				System.out.println("Do you need someting else (y/n)");
				char ch=scanner.next().charAt(0);
				if(ch=='y') {
					book.ReCall();
				}
				else {
					String s = "😀"; 
					System.out.println("Thank You "+s);
				}
	}

}
