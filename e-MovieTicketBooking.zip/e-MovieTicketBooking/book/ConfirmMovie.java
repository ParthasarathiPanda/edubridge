package book;

public class ConfirmMovie {


	public static void confirm(int customerChoice) {
		// TODO Auto-generated method stub
		
	}

}
