package book;

import Cancel.Cancel;
import java.util.Scanner;

public class Customer {

	public Customer() {
		Scanner scanner= new Scanner(System.in);
		char option;
		do {
			System.out.println("Enter Your Choice");
			System.out.println("1: Ticket Booking \n2: Cancel");
			int choice= scanner.nextInt();
			switch(choice) {
			case 1:
				Booking booking = new Booking();
				break;
			case 2:
				Cancel cancel= new Cancel();
				break;
			default:
				System.out.println("invalid choice");
				break;
			}
			System.out.println("Do you want to continue (y/n)");
			option=scanner.next().charAt(0);
		}while(option=='y' || option=='Y');
	}

}
