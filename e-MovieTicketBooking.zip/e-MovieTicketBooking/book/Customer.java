package book;

import Cancel.Cancel;
import java.util.Scanner;

public class Customer {

	public Customer() {
		Scanner scanner= new Scanner(System.in);
		char option;
		do {
			System.out.println("Enter Your Choice");
			System.out.println(" 1: Ticket Booking \n 2: Cancel");
			int choice= scanner.nextInt();
			switch(choice) {
			case 1:
				
				Booking.display();
				System.out.println("Enter the movie number you want to book");
				int customerChoice=scanner.nextInt();
				Booking.book(customerChoice);
				
				break;
			case 2:
				Cancel cancel= new Cancel();
				break;
			default:
				System.out.println("invalid choice");
				break;
			}
			System.out.println("Do you want to continue (y/n)");
			option=scanner.next().charAt(0);
		}while(option=='y' || option=='Y');
		
		System.out.println("Do you need someting else (y/n)");
		char ch=scanner.next().charAt(0);
		if(ch=='y') {
			book.ReCall();
		}
		else {
			String s = "😀"; 
			System.out.println("Thank You "+s);
		}
	}

}
