package book;
import java.util.Scanner;

import Cancel.Cancel;

public class book {
	static Scanner scanner= new Scanner(System.in);

	public static void main(String[] args) {
		Booking booking = new Booking();
		
		System.out.println("Welcome To BookMyShow.com");
		System.out.println("Login First");
		System.out.println(" 1: Login as a Customer");
		System.out.println(" 2: Login as a Admin");
		int ch= scanner.nextInt();
		switch(ch) {
		case 1:
			Customer customer = new Customer();
			break;
			
		case 2:
			Admin admin = new Admin();
			break;
			
		default:
			System.out.println("invalid choice");
			break;
		}
				
	}

	public static void ReCall() {
		System.out.println(" 1: Login as a Customer");
		System.out.println(" 2: Login as a Admin");
		int ch= scanner.nextInt();
		switch(ch) {
		case 1:
			Customer customer = new Customer();
			break;
			
		case 2:
			Admin admin = new Admin();
			break;
			
		default:
			System.out.println("invalid choice");
			break;
		}
				
		
	}

}
