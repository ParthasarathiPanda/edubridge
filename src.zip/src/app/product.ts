export class Product {
    constructor(
        public id:number,
        public image:String,
        public productName:String,
        public productDetails:String,
        public productPrice:number,
    ){}
}
