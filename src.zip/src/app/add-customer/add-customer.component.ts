import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit{
  customer=new Customer(0,"","",new Date,"","","","","","","","",);
message="";
  constructor(private customerService:CustomerService,private router:Router) { }

  ngOnInit(): void {
    //this.customer.gender="Male"
  }
  customerRegister(){
    this.customerService.customerRegisterService(this.customer).subscribe(
      data =>{console.log("Registration Succes"),
    this.router.navigate(['\customersList'])},
      error =>{console.log("Login Failed"),
    this.message="login failed. try again"})
    }
    genders=["Male","Female","Other"]
    back()
    {
      this.router.navigate(['/adminHome'])
    }
}
