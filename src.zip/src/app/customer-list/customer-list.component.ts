import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  customers: any;
    constructor(private customerService:CustomerService,private router:Router) { }
  
    ngOnInit(): void {
      this.customerService.getAllCustomersService().subscribe(
        data=>this.customers=data,
        error=>console.log(error)
      )
    }

    updateCustomer(id:number)
  {
    this.router.navigate(['/customerProfile',id]);
  }
  
  deleteCustomer(id:number)
  {
  this.customerService.deleteCustomerService(id).subscribe(
    data=>{console.log("succuss"),
    this.customerService.getAllCustomersService().subscribe(
      data=>this.customers=data)},
      error=>console.log(error)
  )
  }
}  

