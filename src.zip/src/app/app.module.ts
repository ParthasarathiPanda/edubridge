import { HttpClient, HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { CustomerRegistrationComponent } from './customer-registration/customer-registration.component';
import { IndexComponent } from './index/index.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AdminSignUpComponent } from './admin-sign-up/admin-sign-up.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { ProductListComponent } from './product-list/product-list.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { AddProductComponent } from './add-product/add-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { AboutUsComponent } from './about-us/about-us.component';

@NgModule({
  declarations: [
    AppComponent,
    CustomerLoginComponent,
    
    CustomerHomeComponent,
         CustomerRegistrationComponent,
         IndexComponent,
         ContactUsComponent,
         AdminSignUpComponent,
         AdminHomeComponent,
         CustomerListComponent,
         ProductListComponent,
         AddCustomerComponent,
         AddProductComponent,
         UpdateProductComponent,
         CustomerProfileComponent,
         AboutUsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
