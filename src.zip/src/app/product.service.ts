import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8088/api/products";

  public createProductService(product:Product):Observable<Object>
  {
  return this.http.post<any>("http://localhost:8088/api/products/register",product)
  }
  
  public getAllProductService():Observable<Product[]>
  {
  return this.http.get<Product[]>("http://localhost:8088/api/products/all");
  }

  public getProductByIdService(id:number):Observable<Product>
  {

  return this.http.get<Product>(`${this.url}/${id}`);
  }

  public updateProductService(id:number,product:Product):Observable<any>
  {
  return this.http.put(`${this.url}/${id}`,product);
  }
  
  public deleteProductService(id:number):Observable<any>
  {
  return this.http.delete(`${this.url}/${id}`);
  }
}
