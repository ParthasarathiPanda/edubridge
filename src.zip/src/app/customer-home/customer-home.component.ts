import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {
  products:any;
  customerId:any;
  constructor(private productService:ProductService,private route:Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
  this.customerId=this.activatedRoute.snapshot.params["customerId"]
    console.log(this.customerId);
    this.getProductList();
  }
  private getProductList()
  {
      this.productService.getAllProductService().subscribe(
      data=>this.products=data,
      error=>console.log(error)
    );
  }

  customerProfile()
  {
    this.route.navigate(['/customerProfile',this.customerId])
  }
    
    logOut()
    {
      this.route.navigate(['/'])
    }

    back()
    {
      this.route.navigate(['/',this.customerId])
    }
    bookingDetails ()
    {
      this.route.navigate(['/viewbookinglist',this.customerId])
    }
    contactUs()
    {
      this.route.navigate(['/contact'])
    }
}
