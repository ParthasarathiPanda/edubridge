export class Customer {
    constructor(
        public customerId:number,
        public firstName:String,
        public lastName:String,
        public dateOfBirth:Date,
        public phoneNumber:String,
        public district:String,
        public state:String,
        public zipCode:String,
        public emailID:String,
        public password:String,
        public image:String,
        public gender:String
    ){}
}
