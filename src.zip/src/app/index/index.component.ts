import { assertPlatform, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
  products:any;
  customerId:any;
  constructor(private productService:ProductService,private route:Router,private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
  this.customerId=this.activatedRoute.snapshot.params["customerId"]
    console.log(this.customerId);
    this.getProductList();
  }
  private getProductList()
  {
      this.productService.getAllProductService().subscribe(
      data=>this.products=data,
      error=>console.log(error)
    );
  }

  customerProfile()
  {
    this.route.navigate(['/customerProfile',this.customerId])
  }

  bookProduct()
  {
    alert("Please login");
    this.route.navigate(['/customerLogin'])
  }

}
