import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';



@Component({
  selector: 'app-customer-registration',
  templateUrl: './customer-registration.component.html',
  styleUrls: ['./customer-registration.component.css']
})
export class CustomerRegistrationComponent implements OnInit{
  customer=new Customer(0,"","",new Date,"","","","","","","","",);
message="";
  constructor(private customerService:CustomerService,private router:Router) { }

  ngOnInit(): void {
    //this.customer.gender="Male"
  }
  customerRegister(){
    this.customerService.customerRegisterService(this.customer).subscribe(
      data =>{console.log("Registration Succes"),
    this.router.navigate(['\customerLogin'])},
      error =>{console.log("Login Failed"),
    this.message="login failed. try again"})
    }
    genders=["Male","Female","Other"]
    back()
    {
      this.router.navigate(['/'])
    }
}
