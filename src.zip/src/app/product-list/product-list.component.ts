import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: any;
  constructor(private productService:ProductService,private router:Router) { }

  ngOnInit(): void {
    this.productService.getAllProductService().subscribe(
      data=>this.products=data,
      error=>console.log(error)
    )
  }
  updateProduct(id:number)
  {
    this.router.navigate(['/updateProduct',id]);
  }
  
  deleteProduct(id:number)
  {
  this.productService.deleteProductService(id).subscribe(
    data=>{console.log("succuss"),
    this.productService.getAllProductService().subscribe(
      data=>this.products=data)},
    error=>console.log("error")
  )
  }
  
}  

