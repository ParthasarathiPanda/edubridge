export class Admin {
    constructor(
    public id: number,
    public emailId: string,
    public userName: string,
    public password: string
    ){}   
}
