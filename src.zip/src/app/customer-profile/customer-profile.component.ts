import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {
  customer=new Customer(0,"","",new Date,"","","","","","","","",);
  customerId:any;
  constructor(private customerService:CustomerService,private activatedRoute:ActivatedRoute,private route:Router) { }

  ngOnInit(): void {
    this.getCustomerDetails();
  }
  getCustomerDetails(){
    //take id from url is not working
    this.customerId=5;//this.activatedRoute.snapshot.params["customerId"]
    console.log("id"+this.customerId);
      this.customerService.getCustomerById(this.customerId).subscribe(
        data=>{this.customer=data,
        console.log(data)}
    )
        }
        saveProfile(customerId:number,customer:Customer)
        {
          this.customerService.saveProfileService(customerId,customer).subscribe(
            data=>{console.log(data),
            alert("Profile Updated Successfully");
            this.route.navigate(['\customerHome',customerId])},
            error=>console.log(error)
          )
        }
        backToCustomerHome(customerId:number)
        {
        this.route.navigate(['\customerHome',customerId])
        }
        logOut()
        {
          this.route.navigate(['/'])
        }
        home()
        {
          this.route.navigate(['/customerHome',this.customerId])
        }
        customerProfile()
        {
          this.route.navigate(['/customerProfile',this.customerId])
        }
        genders=["Male","Female","Other"]
        contactUs()
        {
          this.route.navigate(['/contact'])
        }
}