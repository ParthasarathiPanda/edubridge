import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { AddProductComponent } from './add-product/add-product.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminSignUpComponent } from './admin-sign-up/admin-sign-up.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { CustomerProfileComponent } from './customer-profile/customer-profile.component';
import { CustomerRegistrationComponent } from './customer-registration/customer-registration.component';
import { IndexComponent } from './index/index.component';
import { ProductListComponent } from './product-list/product-list.component';
import { UpdateProductComponent } from './update-product/update-product.component';


const routes: Routes = [
  {path:'',component:IndexComponent},
  {path:'customerLogin',component:CustomerLoginComponent},
  {path: 'customerHome/:customerId', component: CustomerHomeComponent},
  {path: 'registration',component:CustomerRegistrationComponent},
  {path: 'contactUs',component:ContactUsComponent},
  {path: 'adminLogin',component:AdminSignUpComponent},
  {path: 'adminHome',component:AdminHomeComponent},
  {path: 'customersList',component:CustomerListComponent},
  {path: 'productsList',component:ProductListComponent},
  {path: 'addCustomer',component:AddCustomerComponent},
  {path: 'addProduct',component:AddProductComponent},
  {path: 'updateProduct/: productId',component:UpdateProductComponent},
  {path: 'customerProfile/: customerId',component:CustomerProfileComponent},
  {path: 'aboutUs',component:AboutUsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
