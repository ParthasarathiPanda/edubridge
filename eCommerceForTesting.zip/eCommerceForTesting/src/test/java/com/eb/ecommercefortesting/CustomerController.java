package com.eb.ecommercefortesting;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.eb.ecommercefortesting.model.Customer;
import com.eb.ecommercefortesting.repository.CustomerRepository;


@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CustomerController {

	@Autowired
	CustomerRepository customerRepository; 

	@Test
	@Order(1)
	public void getAdminTesting()
	{
		Optional<Customer> customer = this.customerRepository.findByEmailID("customerTwo123@gmail.com");
		System.out.println(customer+"****");
		 //assertNotNull(customer.getCustomerByEmail());
	}

}
