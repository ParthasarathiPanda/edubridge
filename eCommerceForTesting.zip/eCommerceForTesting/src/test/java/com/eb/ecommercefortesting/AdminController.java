package com.eb.ecommercefortesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.eb.ecommercefortesting.model.Admin;
import com.eb.ecommercefortesting.repository.AdminRepository;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AdminController {
	@Autowired
	AdminRepository adminRepository; 

	@Test
	@Order(1)
	public void getAdminTesting()
	{
		Admin admin = this.adminRepository.findByEmailId("admin123@gmail.com");
		System.out.println(admin+"****");
		 assertNotNull(admin.getUserName());
	}

//	@Test
//	@Order(2)
//	public void getAdminFalseTesting()
//	{
//		Admin admin = this.adminRepository.findByEmailId("");
//		assertNull( admin.getUserName());
//	}
}
