package com.eb.ecommercefortesting.controller;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.eb.ecommercefortesting.model.Admin;
import com.eb.ecommercefortesting.service.AdminService;




@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class AdminController {
	@Autowired
	private AdminService adminService;
	
	@PostMapping("/register")
	
	public Admin registerUser(@RequestBody Admin admin ) throws Exception {
		
		String userMail = admin.getEmailId();
		if(userMail != null && !"".equals(userMail)) {
			Admin user = adminService.fetchUserByEmailId(userMail);
			if(user != null) {
				throw new Exception("User with "+userMail+" already exist");
			}
		}
		Admin user = null;
		user = adminService.saveUser(admin);
		return user;
	}
	
	@PostMapping("/login")
	
	public Admin loginUser(@RequestBody Admin admin) throws Exception {
		String userMailId = admin.getEmailId();
		String userPassword = admin.getPassword();
		Admin user = null;
		if(userMailId != null && userPassword != null) {
			user = adminService.fetchUserByEmailIdAndPassword(userMailId,userPassword);
		}
		if(user == null) {
			throw new Exception ("user not exist, Enter the register mail and password");
		}
		return user;
	}

}
