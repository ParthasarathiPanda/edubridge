package com.eb.ecommercefortesting.service;

import java.util.List;

import com.eb.ecommercefortesting.model.Product;

public interface ProductService {
	Product addProduct(Product product);
	Product getProductById(long id);
	Product updateProduct(Product product, long id);
	void deleteProduct(long id);
	List<Product> getAllProducts();
}
