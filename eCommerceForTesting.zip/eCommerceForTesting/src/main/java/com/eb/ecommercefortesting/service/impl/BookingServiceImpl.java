package com.eb.ecommercefortesting.service.impl;

import java.sql.Date;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eb.ecommercefortesting.exception.ProductNotFoundException;
import com.eb.ecommercefortesting.model.Booking;
import com.eb.ecommercefortesting.model.Customer;
import com.eb.ecommercefortesting.model.Product;
import com.eb.ecommercefortesting.repository.BookingRepository;
import com.eb.ecommercefortesting.service.BookingService;
import com.eb.ecommercefortesting.service.CustomerService;
import com.eb.ecommercefortesting.service.ProductService;

@Service
public class BookingServiceImpl implements BookingService{
	@Autowired
	private BookingRepository bookingRepository;
	@Autowired
	private ProductService productService;

	@Autowired
	private CustomerService customerService;


	 public BookingServiceImpl(BookingRepository bookingRepository, ProductService productService, CustomerService customerService) {
		     super();
		     this.bookingRepository = bookingRepository;
		     this.productService = productService;
	      	 this.customerService = customerService;

	            }



	@Override
	public Booking addBooking(Booking booking,long customerId,long productId)
	    {
		Product product=productService.getProductById(productId);
		Customer customer=customerService.getCustomerById(customerId);
		booking.setProduct(product);
//		booking.setProductName(product.getProductName());
//		booking.setProductPrice(product.getProductPrice());
        booking.setCustomer(customer);
		return bookingRepository.save(booking);
	      }


    @Override
	public List<Booking> getBookingByCustomerId(long customerId)
	{
		return bookingRepository.findByCustomerCustomerId(customerId);
 
	}
	
	@Override
	public Booking updateBooking(Booking booking, long id) {
		Booking existingBooking=bookingRepository.findById(id).orElseThrow(()->new ProductNotFoundException("Booking","Id",id));
		//existingBooking.setProductPrice(booking.getProductPrice());
		existingBooking.setCustomer(booking.getCustomer());
		existingBooking.setBookedDate(booking.getBookedDate());

		bookingRepository.save(existingBooking);
		return existingBooking;
	}



	@Override
	public void deleteBooking(long id) {
		bookingRepository.findById(id).orElseThrow(()->new ProductNotFoundException("Booking","Id",id));
		bookingRepository.deleteById(id);
		
	}



	@Override
	public List<Booking> getAllBookings() {
		return bookingRepository.findAll();
	}
	
	
}
