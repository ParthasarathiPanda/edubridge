package com.eb.ecommercefortesting.service;

import java.sql.Date;
import java.util.List;

import com.eb.ecommercefortesting.model.Booking;


public interface BookingService {
	Booking addBooking(Booking booking,long customerId,long productId);
	
	Booking updateBooking(Booking booking,long id);
	List<Booking> getAllBookings();
	void deleteBooking(long id);

	List<Booking> getBookingByCustomerId(long customerId);
}
