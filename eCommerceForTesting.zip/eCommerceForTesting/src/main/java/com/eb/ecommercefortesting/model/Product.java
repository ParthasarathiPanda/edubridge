package com.eb.ecommercefortesting.model;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="product_table")
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="product_id")
	private long id;
	
	@Column(name="image")
	@NotEmpty
	private String image;
	
	@Column(name="product_name")
	@NotEmpty
	@Size(min=3 , message="productName must contain atleast 3 characters")
	private String productName;
	
	@Column(name="product_details")
	@NotEmpty
	@Size(min=8 , message="productDetails must contain atleast 8 characters")
	private String productDetails;
	
	@Column(name="product_price")
	@NotEmpty
	@Size(min=8)
	private long productPrice;
	
	@OneToOne(mappedBy="product", cascade=CascadeType.REMOVE)
	@JsonIgnore
	private Booking booking;
	
//	@OneToOne(mappedBy="product", cascade=CascadeType.REMOVE)
//	@JsonIgnore
//	private Payement payement;


	public Product()
	{}
	

	public long getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(long productPrice) {
		this.productPrice = productPrice;
	}
		
	
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getProductDetails() {
		return productDetails;
	}


	public void setProductDetails(String productDetails) {
		this.productDetails = productDetails;
	}

	

	


	public Booking getBooking() {
		return booking;
	}


	public void setBooking(Booking booking) {
		this.booking = booking;
	}


	

//	public Payement getPayement() {
//		return payement;
//	}
//
//
//	public void setPayement(Payement payement) {
//		this.payement = payement;
//	}


@Override
public String toString() {
	return "Product [productId=" + id + ", productName=" + productName + "]";
	}
}
