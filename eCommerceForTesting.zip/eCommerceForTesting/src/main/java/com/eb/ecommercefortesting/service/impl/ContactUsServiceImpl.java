package com.eb.ecommercefortesting.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eb.ecommercefortesting.exception.ContactNotFoundException;
import com.eb.ecommercefortesting.model.ContactUs;
import com.eb.ecommercefortesting.repository.ContactUsRepository;
import com.eb.ecommercefortesting.service.ContactUsService;

@Service
public class ContactUsServiceImpl implements ContactUsService{
	
	@Autowired
	private ContactUsRepository contactUsRepository;
		
		
		
		public ContactUsServiceImpl(ContactUsRepository contactUsRepository) {
			super();
			this.contactUsRepository = contactUsRepository;
		}


	@Override
	public ContactUs saveContact(ContactUs contactUs) {
		return contactUsRepository.save(contactUs);
	}
	
	@Override
	public ContactUs getContactById(long id) {
		
		return contactUsRepository.findById(id);
	}

	@Override
	public ContactUs updateContact(ContactUs contactUs, long id) {
		ContactUs existingContact=contactUsRepository.findById(id);	
		existingContact.setPhoneNumber(contactUs.getPhoneNumber());
		existingContact.setEmailID(contactUs.getEmailID());
		existingContact.setWebsite(contactUs.getWebsite());
		contactUsRepository.save(existingContact);
		return existingContact;
	}

	@Override
	public List<ContactUs> getAllContact() {
		return contactUsRepository.findAll();
	}

	@Override
	public void deleteContact(long id) {
		contactUsRepository.findById(id);
		contactUsRepository.deleteById(id);
		
	}

	
}
