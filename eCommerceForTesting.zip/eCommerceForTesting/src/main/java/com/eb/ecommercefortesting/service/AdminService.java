package com.eb.ecommercefortesting.service;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.eb.ecommercefortesting.model.Admin;
import com.eb.ecommercefortesting.repository.AdminRepository;

@Service
public class AdminService {
	@Autowired
	private  AdminRepository adminRepository;
	
	public Admin saveUser(Admin admin) {
		
		return adminRepository.save(admin);	
	}

	public Admin fetchUserByEmailId(String email) {
		
		return adminRepository.findByEmailId(email);
	}
	
	public Admin fetchUserByEmailIdAndPassword(String email,String password) {
		
		return adminRepository.findByEmailIdAndPassword(email, password);
	}

}
