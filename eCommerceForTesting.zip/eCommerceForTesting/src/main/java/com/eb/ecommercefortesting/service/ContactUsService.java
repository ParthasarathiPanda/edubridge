package com.eb.ecommercefortesting.service;

import java.util.List;


import com.eb.ecommercefortesting.model.ContactUs;

public interface ContactUsService {
	ContactUs saveContact(ContactUs contactUs);
	ContactUs updateContact(ContactUs contactUs,long id);
	List<ContactUs> getAllContact();
	ContactUs getContactById(long id);
	void deleteContact(long id);

}
