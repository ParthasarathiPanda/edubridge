package com.eb.ecommercefortesting.model;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="booking_table")
public class Booking {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="booking_id")
	private long bookingId;
	
	@Column(name="booked_date")
	private Date bookedDate;
	
	@Column(name="payement_id")
	private String payementId;
	
	@Column(name="dalivary_address")
	private String dalivaryAddress;
	
	@Column(name="dalivary_status")
	private String dalivaryStatus;
	
	@Column(name="product_name")
	private String productName;
	
	@Column(name="product_price")
	private long productPrice;
	
	
	
	@OneToOne( cascade=CascadeType.MERGE)
	@JsonIgnore
    private Product product;
	
	@ManyToOne( cascade=CascadeType.MERGE)
	@JoinColumn(name="customer_id")
	@JsonIgnore
    private Customer customer;


	public long getBookingId() {
		return bookingId;
	}

	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}

	
	public Date getBookedDate() {
		return bookedDate;
	}

	public void setBookedDate(Date bookedDate) {
		this.bookedDate = bookedDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getPayementId() {
		return payementId;
	}

	public void setPayementId(String payementId) {
		this.payementId = payementId;
	}

	public String getDalivaryAddress() {
		return dalivaryAddress;
	}

	public void setDalivaryAddress(String dalivaryAddress) {
		this.dalivaryAddress = dalivaryAddress;
	}

	public String getDalivaryStatus() {
		return dalivaryStatus;
	}

	public void setDalivaryStatus(String dalivaryStatus) {
		this.dalivaryStatus = dalivaryStatus;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public long getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(long productPrice) {
		this.productPrice = productPrice;
	}

	
	
	

}
