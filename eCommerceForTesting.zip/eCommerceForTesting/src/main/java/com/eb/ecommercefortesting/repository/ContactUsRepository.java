package com.eb.ecommercefortesting.repository;

import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eb.ecommercefortesting.model.ContactUs;


@Repository
public interface ContactUsRepository extends JpaRepository<ContactUs, Long> {
	ContactUs findById(long ID);

	ContactUs save(ContactUs existingContact);
}
